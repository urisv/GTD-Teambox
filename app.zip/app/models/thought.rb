class Thought < ActiveRecord::Base
end
