class NextTasks < ActiveRecord::Base
  belongs_to :list
end
