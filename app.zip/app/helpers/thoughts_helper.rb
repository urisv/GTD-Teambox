module ThoughtsHelper
end
